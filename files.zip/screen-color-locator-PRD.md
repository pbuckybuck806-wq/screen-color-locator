# Screen + Color Locator — Build Spec (PRD)

**Purpose of this document:** a complete, buildable specification for Claude Code. Pair it with two files: `screen-color-locator-schema.sql` (database) and `paint-colors-seed-template.csv` (seed data). The visual reference is `screen-locator-prototype-v6-final.html` — the app should look and behave like that prototype.

---

## 1. What we're building

A tool for a screen-printing shop that lets floor **operators instantly locate two things**: (a) a physical silk-screen among ~900 screens across ~30 carts, and (b) a bucket of ink among dozens of buckets. Today both are hunted for by hand, costing large amounts of productive time. The app replaces the hunt with a search.

It is **one app with two search modes** (Screens, and Paint & Colors), plus an analytics console for techs, joined to the existing **Package Help Desk** app by a shared hub landing page.

---

## 2. Users & roles

- **Operator** — *no login.* Uses a public page. Can search screens and paint, mark a bucket's status, and return a screen/bucket to a shelf. Because there is no login, any "return" is authorized by **scanning the physical shelf/bin barcode**, not by typing a location.
- **Tech** — *has a login.* Everything operators can do, plus: create/log screens and their separation references, place screens, send screens to wash, and view Analytics.
- **Admin** — *has a login.* Tech abilities plus user management and seed/maintenance (mirrors Package Help Desk's Inbound/Production/Admin idea).

Auth should reuse the **same mechanism as Package Help Desk** if practical.

---

## 3. Navigation & layout (firm requirement)

- A **persistent, sticky top navigation bar** across the top of every screen (matches the prototype). It switches the main area between views **instantly, without full page reloads** (SPA-style).
- The nav is **role-aware**: an operator effectively sees only the Locator; a signed-in tech/admin also sees **Analytics**. (In the prototype all tabs show for demo convenience — in production, gate Analytics behind login.)
- Each view is **single-purpose and uncluttered** — one job's worth of content per screen. This clean feel is a core design goal, not incidental.
- Keep the top nav as-is on tablets for now (no responsive bottom-bar fallback in v1).

---

## 4. Hub (shared landing page)

- A welcome page with two large tiles: **Screen & Color Locator** and **Package Help Desk** (the existing app).
- Selecting Screen & Color Locator plays a short **"floor-dive" transition** (the aerial shop photo settles in to the native frame — see prototype) then opens the locator.
- Selecting Package Help Desk routes to that existing app (no animation).
- Likely delivered via **subdomains** (e.g. `screens.yourco.com`, `packages.yourco.com`) with a root landing page linking both. Keep the two apps as **separate codebases/databases**; the hub is the only shared surface.

---

## 5. App — Screens mode

### 5.1 Tech entry flow (logging a freshly-shot screen)
Step-by-step prompts: **screen number → separation reference → "add another reference?" (up to 4) → scan the shelf barcode to place it.** Placing writes a `placements` row for the screen's open cycle.

### 5.2 Operator search
Enter a **Separation Reference** → return the screen's **cart + shelf**, its **cycle number**, and every reference on the screen with per-reference status. The result card animates in with the **squeegee "print wipe"** animation (see §9).

### 5.3 Three-layer status model
- **Reference status:** `pending` → `in_production` → `completed`.
- **Screen status (derived, never manually synced):**
  - `in_production` if any reference is currently checked out (active checkout),
  - `completed` (a.k.a. **due for wash**) if no active checkout and *all* references are completed,
  - `on_shelf` otherwise.
- **Progress** like "2/3 complete" = completed references ÷ total references for the current cycle.

### 5.4 Production conflict alert
If an operator searches a screen that is **currently checked out to another job**, the result must clearly show it's **unavailable / in production** (which reference is running), rather than letting a second job claim the same physical screen.

### 5.5 Return to shelf (no login)
Operator finishes a job → **scans a shelf barcode** to return the screen. This closes the active checkout (`returned_at`, `returned_shelf_id`) and/or writes a new placement. Scanning is the authorization.

### 5.6 Cycle / wash (append-only history)
A screen is washed and reshot repeatedly. Each wash **closes the current cycle and opens a new one** (`cycle_number + 1`). All references/placements/checkouts attach to a specific `cycle_id`, so **new-cycle data never overwrites old-cycle data**. Search shows only the **current** cycle by default; older cycles remain permanently stored and retrievable on request. (See schema header for the exact operation.)

---

## 6. App — Paint & Colors mode

- Operator enters a **PMS code** → returns the bucket's **location (rack + bin)**, a color **swatch** (from `hex`), and current **status**.
- Operator can **mark the bucket** `Full` / `In use` / `Empty` (no login). Each change writes an append-only `bucket_status_events` row and updates the bucket's current status.
- Multiple buckets may exist per color; a color with an empty bucket surfaces in the replenishment list.
- The found-result animation here is the **paint splash**, colored by the ink's real hex (keep as in the prototype — this mode does **not** use the squeegee).

---

## 7. Analytics (tech console, behind login)

Two dashboards behind a **Screens | Colors & Ink** toggle:

**Screens dashboard:** hero "locate time" stat; counts (on floor, in production now, completed today, due for wash); cart utilization; reference status by channel; recycle/wash queue.

**Colors & Ink dashboard (executive replenishment view):** counts (colors logged, full, in use, **needs refill**); a **"Needs replenishment" list** of every bucket marked empty (color, code, location); bucket-status breakdown; most-used inks. Marking a bucket empty in the locator must show up here.

All analytics numbers are **computed from live data**, not stored snapshots.

---

## 8. Barcode scanning (USB keyboard-wedge)

Scanners are **USB keyboard-wedge handheld guns** — they emit the barcode's characters followed by an Enter, into whatever field is focused. So "scan a shelf/bin" is implemented as: **focus a text input, receive the scanned string + Enter, look it up by `barcode`.** No camera/permissions/mobile-vision needed. Shelves and paint bins carry barcodes (`shelves.barcode`, `paint_bins.barcode`).

---

## 9. Visual & interaction reference

- Build the UI to match **`screen-locator-prototype-v6-final.html`**.
- **Fonts:** Bricolage Grotesque (display) + Inter (body). No condensed/monospace.
- **Palette:** CMYK-grounded — process cyan (primary accent), magenta (in production), yellow (completed), orange (on shelf / refill), plus green for "full/complete." Dark UI.
- **Signature motif:** registration mark (crosshair).
- **Found animations:** Screens mode = **squeegee print wipe** (a squeegee bar sweeps across and "prints" the result into view). Paint & Colors = **paint splash** in the ink's color. Respect `prefers-reduced-motion`.
- Living background (drifting CMYK orbs, halftone) as in the prototype.

---

## 10. Seed data

- **Paint colors:** import from `paint-colors-seed-template.csv` (replace samples with the real PMS export: `pms_code, name, hex, default_rack, default_bin, initial_status`).
- **Carts & shelves:** generate carts `A`..`DD` (~30) and shelves `A1`..`DD30` (30 each), assigning each shelf a unique barcode. Claude Code can generate these programmatically.
- **Screens:** numbers `1`..`900` exist as physical frames; cycles/references are created as techs log them.

---

## 11. Tech stack

**Match the existing Package Help Desk repo** — detect it from the project files (`package.json` → JS/React/Next; `composer.json` → PHP/Laravel; `requirements.txt`/`manage.py` → Python/Django; `Gemfile` → Rails) and mirror its framework, database, auth, and hosting so the two apps feel like siblings.

**If this is a fresh standalone project**, a recommended default: **Next.js (React) + PostgreSQL** (e.g. Supabase for DB + auth + hosting), which cleanly supports the SPA nav, the public operator page, gated tech analytics, and the provided schema.

---

## 12. Definition of done (acceptance criteria)

1. Operator (no login) can search a Separation Reference and see the screen's cart + shelf, cycle, references, and derived status — with the squeegee animation.
2. Searching an in-production screen shows the unavailable/conflict alert.
3. Operator can scan a shelf barcode to return a screen; no manual location typing.
4. Tech (login) can log a screen: number → reference(s) up to 4 → scan shelf to place.
5. Washing a screen opens a new cycle; prior cycle data is preserved and never overwritten; default search shows only the current cycle.
6. Operator can search a PMS code, see location + swatch + status, and mark Full/In use/Empty (append-only history).
7. Analytics (behind login) shows the Screens and Colors dashboards; an empty-marked bucket appears in the replenishment list.
8. Persistent sticky role-aware top nav; instant view switching; each view single-purpose; visuals match `v6-final`.
9. Hub links Screen & Color Locator and Package Help Desk; separate codebases/DBs.

---

## 13. Out of scope (v1)

Responsive bottom-nav fallback for small screens; camera-based scanning; multi-warehouse; deep Package Help Desk changes (only the shared hub link).
