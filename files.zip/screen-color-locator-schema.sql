-- ============================================================================
-- Screen + Color Locator — Database Schema (PostgreSQL flavor, portable)
-- ----------------------------------------------------------------------------
-- Design principles baked into this schema:
--   1. APPEND-ONLY CYCLE HISTORY. A physical screen is reused across many
--      wash/reshoot cycles. Each cycle is its own row; all references,
--      placements, and checkouts hang off a specific cycle_id. New-cycle data
--      NEVER overwrites old-cycle data — old cycles are simply closed and kept.
--   2. DERIVED SCREEN STATUS. A screen's overall status is computed from its
--      references + active checkouts, never manually synced.
--   3. SCAN-TO-RETURN. Shelves and paint bins carry barcodes. Operators (no
--      login) authorize a "return" by scanning the physical shelf/bin barcode,
--      which is captured as an append-only event.
-- ============================================================================

-- ---------- USERS & ROLES ----------------------------------------------------
-- Operators have NO login and are not represented here. Only techs/admins.
CREATE TABLE users (
  id            BIGSERIAL PRIMARY KEY,
  name          TEXT NOT NULL,
  email         TEXT UNIQUE,
  role          TEXT NOT NULL CHECK (role IN ('tech','admin')),
  password_hash TEXT,               -- or delegate to the same auth as Package Help Desk
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- PHYSICAL LOCATIONS: CARTS & SHELVES ------------------------------
CREATE TABLE carts (
  id    BIGSERIAL PRIMARY KEY,
  code  TEXT NOT NULL UNIQUE,       -- 'A' .. 'DD'  (~30 carts)
  label TEXT
);

CREATE TABLE shelves (
  id       BIGSERIAL PRIMARY KEY,
  cart_id  BIGINT NOT NULL REFERENCES carts(id),
  code     TEXT NOT NULL UNIQUE,    -- 'A1','A2', ... 'DD30'  (barcode-labeled)
  barcode  TEXT NOT NULL UNIQUE,    -- value the keyboard-wedge gun emits
  position INT                      -- 1..30 within the cart
);

-- ---------- SCREENS (the physical frame; persists across cycles) -------------
CREATE TABLE screens (
  id            BIGSERIAL PRIMARY KEY,
  screen_number INT NOT NULL UNIQUE CHECK (screen_number BETWEEN 1 AND 900),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- SCREEN CYCLES (one row per wash/reshoot life) --------------------
-- current cycle for a screen = the row with closed_at IS NULL (only one open).
CREATE TABLE screen_cycles (
  id           BIGSERIAL PRIMARY KEY,
  screen_id    BIGINT NOT NULL REFERENCES screens(id),
  cycle_number INT NOT NULL,        -- 1,2,3... increments each wash
  opened_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  closed_at    TIMESTAMPTZ,         -- set when the screen is washed -> cycle ends
  UNIQUE (screen_id, cycle_number)
);
-- Enforce "only one open cycle per screen" via a partial unique index:
CREATE UNIQUE INDEX one_open_cycle_per_screen
  ON screen_cycles (screen_id) WHERE closed_at IS NULL;

-- ---------- SEPARATION REFERENCES (tied to a specific cycle) -----------------
-- Up to 4 designs (references) per screen per cycle.
CREATE TABLE separation_references (
  id               BIGSERIAL PRIMARY KEY,
  screen_cycle_id  BIGINT NOT NULL REFERENCES screen_cycles(id),
  ref_code         TEXT NOT NULL,   -- the "Separation Reference" number
  design_name      TEXT,
  channel          TEXT,            -- optional: 'cyan'|'magenta'|'yellow'|'black' (CMYK tag)
  status           TEXT NOT NULL DEFAULT 'pending'
                     CHECK (status IN ('pending','in_production','completed')),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at     TIMESTAMPTZ,
  UNIQUE (screen_cycle_id, ref_code)
);
-- ref_code is unique WITHIN a cycle; the same code may recur in later cycles.

-- ---------- PLACEMENTS (where the screen sits, append-only) ------------------
-- Current location = row for the open cycle with removed_at IS NULL.
CREATE TABLE placements (
  id               BIGSERIAL PRIMARY KEY,
  screen_cycle_id  BIGINT NOT NULL REFERENCES screen_cycles(id),
  shelf_id         BIGINT NOT NULL REFERENCES shelves(id),
  placed_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  removed_at       TIMESTAMPTZ,     -- set when pulled from the shelf
  placed_via_scan  BOOLEAN NOT NULL DEFAULT true
);
CREATE UNIQUE INDEX one_active_placement_per_cycle
  ON placements (screen_cycle_id) WHERE removed_at IS NULL;

-- ---------- CHECKOUTS (production usage, append-only) ------------------------
-- When a reference goes into production the screen is "checked out" to that job.
-- Returned by scanning a shelf barcode (returned_shelf_id).
CREATE TABLE checkouts (
  id                       BIGSERIAL PRIMARY KEY,
  screen_cycle_id          BIGINT NOT NULL REFERENCES screen_cycles(id),
  separation_reference_id  BIGINT NOT NULL REFERENCES separation_references(id),
  checked_out_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  returned_at              TIMESTAMPTZ,
  returned_shelf_id        BIGINT REFERENCES shelves(id)
);
CREATE INDEX active_checkouts ON checkouts (screen_cycle_id) WHERE returned_at IS NULL;

-- DERIVED SCREEN STATUS (compute in the app / a view; do NOT store redundantly):
--   in_production : an active checkout exists (returned_at IS NULL)
--   completed     : no active checkout AND every reference in the open cycle is 'completed'
--   on_shelf      : otherwise (has an active placement, not in production)
-- Reference progress like "2/3 complete" = count(completed)/count(*) for the cycle.

-- ---------- PAINT / INK: COLORS, BINS, BUCKETS -------------------------------
CREATE TABLE paint_colors (
  id        BIGSERIAL PRIMARY KEY,
  pms_code  TEXT NOT NULL UNIQUE,   -- e.g. 'PMS-185'  (from your PMS export)
  name      TEXT NOT NULL,          -- 'Race Red'
  hex       TEXT                    -- '#E4002B' for the on-screen swatch
);

CREATE TABLE paint_bins (
  id      BIGSERIAL PRIMARY KEY,
  rack    TEXT NOT NULL,            -- 'Rack 2'
  bin     TEXT NOT NULL,            -- 'Bin C4'
  barcode TEXT UNIQUE,              -- optional bin barcode for scan-to-locate/return
  UNIQUE (rack, bin)
);

CREATE TABLE paint_buckets (
  id             BIGSERIAL PRIMARY KEY,
  paint_color_id BIGINT NOT NULL REFERENCES paint_colors(id),
  bin_id         BIGINT REFERENCES paint_bins(id),
  label          TEXT,              -- optional per-bucket label
  status         TEXT NOT NULL DEFAULT 'full'
                   CHECK (status IN ('full','in_use','empty')),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Multiple buckets may exist per color. "Needs refill" list = buckets with status 'empty'.

-- Append-only history of who marked a bucket what, and when.
CREATE TABLE bucket_status_events (
  id         BIGSERIAL PRIMARY KEY,
  bucket_id  BIGINT NOT NULL REFERENCES paint_buckets(id),
  status     TEXT NOT NULL CHECK (status IN ('full','in_use','empty')),
  actor      TEXT,                  -- 'operator' (no login) or a user id/name
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- GENERIC AUDIT LOG (optional but recommended) ---------------------
CREATE TABLE events (
  id          BIGSERIAL PRIMARY KEY,
  entity_type TEXT NOT NULL,        -- 'screen','reference','bucket',...
  entity_id   BIGINT NOT NULL,
  event_type  TEXT NOT NULL,        -- 'placed','checked_out','returned','washed','marked_empty'...
  payload     JSONB,
  actor       TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- HELPFUL INDEXES --------------------------------------------------
CREATE INDEX idx_refs_by_code   ON separation_references (ref_code);
CREATE INDEX idx_refs_by_cycle  ON separation_references (screen_cycle_id);
CREATE INDEX idx_buckets_status ON paint_buckets (status);
CREATE INDEX idx_colors_code    ON paint_colors (pms_code);

-- ============================================================================
-- WASH / RECYCLE OPERATION (application logic, described for the builder):
--   1. UPDATE screen_cycles SET closed_at = now() WHERE id = <open cycle>.
--   2. INSERT a new screen_cycles row with cycle_number + 1 (opened_at now()).
--   3. New references/placements/checkouts attach to the NEW cycle_id.
--   => Old cycle rows remain untouched and queryable; nothing is overwritten.
-- Searching a screen shows ONLY the current (open) cycle by default; older
-- cycles are retrievable on request by filtering screen_cycles.cycle_number.
-- ============================================================================
